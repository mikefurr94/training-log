---
name: mike-style
description: >
  Apply Mike's personal design style and aesthetic preferences when building UI, components, or any visual/interactive software.
  ONLY use this skill when the user explicitly invokes it — e.g., says "use my style", "apply mike-style", "build this in my style", or directly references this skill by name.
  Do NOT trigger automatically. This skill should never activate unless the user has clearly asked for it.
---

# Mike's Design Style

When invoked, apply the following design principles and aesthetic sensibilities across everything you build — components, layouts, apps, dashboards, docs, anything with a visual or interactive surface.

These principles are distilled from two sources: Mike's favorite apps (Linear, Notion, Ramp, Claude/Anthropic, YNAB, Slack, Apple Notes, Todoist) and patterns extracted directly from his own past projects (FinanceBuddy, Pomo, PersonalWebsite, TrainingLog).

---

## Core Philosophy

**Do less, but do it precisely.** Every element should justify its presence. Simplicity isn't emptiness — it's the result of removing everything that doesn't earn its spot.

Speed, clarity, and calm are the primary goals. When in doubt, remove something rather than add it.

---

## Typography

- **Primary font: Inter** — this is Mike's actual workhorse across most projects. Use it as the default. Import from Google Fonts or Next.js `next/font/google`.
- For projects that need more warmth or personality (consumer-facing, creative), **Plus Jakarta Sans** or **DM Sans** are excellent upgrades — friendlier and more expressive without being loud.
- **For numeric displays** (timers, financial figures, stats): use **DM Mono** or a monospace stack. Mike uses this in both Pomo (timer: 56px, weight 300) and FinanceBuddy (`tabular-nums` class). Always use `font-variant-numeric: tabular-nums` for aligned number columns.
- Type scale: `xs: 11px`, `sm: 13px`, `base: 14px`, `md: 15px`, `lg: 17px`, `xl: 20px`, `2xl: 24px`, `3xl: 30px`
- Font weights: 400 body, 500 labels/UI, 600 subheadings, 700 primary headings
- Line heights: 1.25 for tight/headings, 1.5 for body
- Always apply `-webkit-font-smoothing: antialiased`

## Backgrounds & Surfaces

Mike never uses pure white as the page background. His actual projects use:
- `#f8f9fa` — TrainingLog, FinanceBuddy (light cool gray)
- `#f4f7f6` — Pomo (warm off-white)
- `#FAF7F2` — PersonalWebsite (warm cream)

**Rule: page background = slightly off-white or off-gray. Cards and surfaces = pure white (`#ffffff`).** This creates a subtle but important sense of elevation without heavy shadows.

Dark mode backgrounds: `#0f1615` (Pomo), `#0f172a`, or `#1a2322` — rich dark, not pure black.

## Spacing & Layout

- **4px base grid** (Mike's actual projects all use this). Common values: 4, 8, 12, 16, 20, 24, 32, 40, 48, 64px.
- Card padding: `12px` compact / `16-20px` standard / `24px` spacious
- Section gaps: `24-32px` between major sections
- Max-width containers: `max-w-3xl` (768px) for focused content, `max-w-4xl` (896px) for dashboards, `max-w-5xl` (1024px) for full layouts
- Sidebar width: 256px (`w-64`) fixed
- Don't center-align body text — left-align for readability

## Color

**Mike's accent color is teal, not blue.** Across his personal projects:
- FinanceBuddy: `oklch(0.55 0.18 240)` (blue-teal)
- Pomo: `#2b8a7e` (teal)
- PersonalWebsite: `#2A9D8F` (teal)
- TrainingLog: `#6366f1` (indigo, for the activity-specific context)

**Default accent: teal (`#2A9D8F` or `#2b8a7e`).** For more data-heavy or structured apps, indigo (`#6366f1`) works well. Avoid generic blue.

**Semantic colors — always muted, never harsh.** Mike's pattern: use a light background tint + deeper text color, never a filled saturated swatch:
- ✅ Green/success: `bg #dcfce7` / `text #15803d` (or `bg-success/10 text-success`)
- ⚠️ Amber/warning: `bg #fef9c3` / `text #a16207`
- ❌ Red/error: `bg #fee2e2` / `text #b91c1c`
- Progress bars: use muted tones, e.g. soft sage for on-track, amber for warning, muted red for over

Hover states use a slightly darker shade of the accent: `#1F7A6F` for teal, `#4f46e5` for indigo.

**Background transparency patterns** (from FinanceBuddy/TrainingLog): `bg-primary/5`, `bg-success/10`, `hover:bg-accent/50` — lean into transparent overlays rather than new hard-coded colors.

## Cards & Surfaces

- **Border radius: 10–16px** on cards. Mike uses `--radius-md: 10px`, `--radius-lg: 16px`, `rounded-xl` (14px) consistently.
- **Shadows: minimal.** Only `shadow-sm` (`0 1px 2-3px rgba(0,0,0,0.05-0.08)`). Never heavy drop shadows.
- **Borders: subtle.** `border border-stone/30` or `1px solid #e5e7eb` — present but quiet.
- Card structure: white surface (`#fff`) elevated above the off-white page background.
- Empty state cards: dashed border (`border-dashed`), centered content, helpful CTA.

## Dark Mode

Dark mode is standard — 3 of 4 of Mike's projects support it. Always wire it up:
- Use CSS variables (`:root` / `.dark`) or `next-themes`
- Dark background: `#0f1615` or `#111827` (not pure `#000`)
- Dark card: `#1a2322` or `#1e293b`
- Adjust semantic color chroma/luminosity for dark (same hues, lighter tones)
- Input backgrounds in dark: semi-transparent, e.g. `dark:bg-input/30`

## Components & Interactions

- **Progressive disclosure**: secondary actions appear on hover or in context menus (three-dot). (Todoist, Slack, TrainingLog)
- **Keyboard-first**: Cmd+K command palette for many-action UIs. (Linear)
- Inputs: `h-9` (36px) standard height, `rounded-md`, focus ring using accent color (`ring-[3px] ring-accent/50`)
- Buttons: `h-9 px-4` default, `h-8 px-3` small, `h-10 px-6` large
- **Stat/summary cards** (dashboard pattern from FinanceBuddy + TrainingLog): uppercase label (11px, 500 weight, letter-spacing 0.06em) → large value (24-28px, bold, tabular-nums) → small subtitle
- Empty states: centered in a dashed-border container, icon + title + description + CTA button

## Navigation & Structure

- **Sidebar** for primary nav: fixed 256px, off-white background slightly different from main, `border-r`
- Active nav item: accent background (`bg-sidebar-accent`), accent text
- Header height: 56px (`h-14`), `border-b`, `bg-background`
- Tab groups (for sub-navigation): pill container with sliding active indicator, spring animation

## Data & Numbers

- **Always use `font-variant-numeric: tabular-nums`** for any column of numbers (financial data, stats, splits)
- Use DM Mono for prominent single numbers (timers, big stat values)
- Progress bars for budget/completion status — height `4-8px`, `rounded-full`
- Right-align numbers in tables, left-align text
- Delta indicators: `▲` green for positive, `▼` red for negative, with `bg-success/10` / `bg-destructive/10` pill backgrounds

## Feedback & Loading

- Skeleton screens for loading states: `animate-pulse`, `bg-muted`, rounded to match the content shape
- Toast notifications for confirmations (bottom-left or bottom-right, `rounded-lg`, brief)
- Transitions: `transition-colors 150ms` standard, `transition-all 100ms` for fast interactions, `250ms` for motion animations
- Button loading state: spinner icon (`animate-spin`) + text change (e.g., "Saving...")
- Never blank states — always skeleton or spinner

## Tone of UI Copy

- Short, clear, direct. Sentence case everywhere (not Title Case).
- Labels: descriptive but terse. "Workspace name" not "Enter the name of your workspace".
- Empty states and tooltips can be slightly warmer — "No tasks yet. Add one to get started."
- Error messages: say what happened + what to do.

---

## What to Avoid

- Pure white page backgrounds (use off-white/off-gray)
- Harsh, saturated semantic fill colors — always use muted bg + deeper text
- Overuse of dividers — use whitespace and padding for separation. Only add a border/divider at a true section break.
- Heavy box shadows
- Generic blue as an accent — Mike's palette leans teal/indigo
- Rainbow palettes — one accent + semantic colors only
- Overcrowded toolbars or action-heavy headers
- Modal dialogs for confirmations that could be inline
- Slow animations (>250ms for transitions)
- Pure black (`#000`) backgrounds in dark mode

---

## Quick Reference

| Principle | Source |
|---|---|
| Inter as default font, DM Mono for numbers | FinanceBuddy, Pomo, TrainingLog |
| Off-white page bg + white card surfaces | All 4 projects |
| 4px base grid | All 4 projects |
| 10–16px card border radius | All 4 projects |
| Teal accent (#2A9D8F) | Pomo, PersonalWebsite, FinanceBuddy |
| Muted semantic colors (bg tint + deep text) | FinanceBuddy, TrainingLog |
| Tabular nums for data | FinanceBuddy, TrainingLog |
| Dark mode via CSS variables | Pomo, FinanceBuddy, TrainingLog |
| Shadow-sm only | All 4 projects |
| Progressive disclosure / hover actions | TrainingLog, FinanceBuddy |
| Sidebar nav, 256px fixed | FinanceBuddy |
| Skeleton loading states | FinanceBuddy, TrainingLog |
| Generous whitespace over dividers | All 4 projects |
| Keyboard-first + Cmd+K | Linear (aspiration) |
